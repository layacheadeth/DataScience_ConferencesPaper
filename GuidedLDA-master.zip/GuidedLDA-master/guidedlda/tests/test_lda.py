# coding=utf-8
from __future__ import absolute_import, unicode_literals  # noqa

import numpy as np
import unittest

import guidedlda


class TestLDA(unittest.TestCase):

    def test_lda_constructor(self):
        n_topics = 10
        model1 = guidedlda.GuidedLDA(n_topics)
        self.assertIsNotNone(model1)
        model2 = guidedlda.GuidedLDA(n_topics=n_topics)
        self.assertIsNotNone(model2)

    def test_lda_params(self):
        n_topics = 10
        model1 = guidedlda.GuidedLDA(n_topics, alpha=0.3)
        self.assertIsNotNone(model1)
        model2 = guidedlda.GuidedLDA(n_topics=n_topics, alpha=0.3, eta=0.4)
        self.assertIsNotNone(model2)
        self.assertRaises(ValueError, guidedlda.GuidedLDA, n_topics, alpha=-3)
        self.assertRaises(ValueError, guidedlda.GuidedLDA, n_topics, eta=-3)
        self.assertRaises(ValueError, guidedlda.GuidedLDA, n_topics, alpha=-3, eta=-3)

    def test_lda_getting_started(self):
        X = np.array([[1, 1], [2, 1], [3, 1], [4, 1], [5, 8], [6, 1]])
        model = guidedlda.GuidedLDA(n_topics=2, n_iter=100, random_state=1)
        doc_topic = model.fit_transform(X)
        self.assertIsNotNone(doc_topic)
        self.assertIsNotNone(model.doc_topic_)
        self.assertIsNotNone(model.components_)

    def test_lda_loglikelihoods(self):
        X = np.array([[1, 1], [2, 1], [3, 1], [4, 1], [5, 8], [6, 1]])
        model = guidedlda.GuidedLDA(n_topics=2, n_iter=100, random_state=1)
        model.fit(X)
        self.assertGreater(len(model.loglikelihoods_), 1)

    def test_guidedlda_getting_started(self):
        X = np.array([[1, 0], [2, 0], [3, 0], [4, 0], [0, 8], [6, 0]])
        model = guidedlda.GuidedLDA(n_topics=2, n_iter=100, random_state=1)
        seed_topics = {0: 0, 1: 1}
        doc_topic = model.fit_transform(X, seed_topics=seed_topics, seed_confidence=0.9)
        self.assertIsNotNone(doc_topic)
        self.assertIsNotNone(model.doc_topic_)
        self.assertIsNotNone(model.components_)
        self.assertEqual(model.word_topic_[0].argmax(), 0)
        self.assertEqual(model.word_topic_[1].argmax(), 1)
